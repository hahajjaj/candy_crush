struct Point
{
    int x, y;
};